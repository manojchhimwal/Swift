import UIKit

func bmiCalculator(weightInKg: Double,heightInFoot: Double, heightInInches: Double ) -> String{
    
    let calcWeightInKg  = weightInKg  //weightInPound * 0.45359237 ;
    let footInInches  = heightInFoot * 12
    let calcHeight = (footInInches + heightInInches) * 0.0254
    
    let bmi = calcWeightInKg / pow(calcHeight,2)
    var interpret = ""
    let roundBmi = String(format: "%.2f", bmi)

    if bmi > 25 {
        interpret = "you are overweight"
    }else if bmi > 18.5 {
        interpret = "you have a normal weight  "
    }else{
        interpret = "you are underweight"
    }
    
    return "your bmi is \(roundBmi) and \(interpret)"
}

var bmiResult = bmiCalculator(weightInKg: 50, heightInFoot: 5, heightInInches: 4)

print(bmiResult)
