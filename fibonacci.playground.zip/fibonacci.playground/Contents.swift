import UIKit

func fibonacci(until:Int){
    
    var firstNumber = 0;
    var secondNumber = 1 ;
    print (firstNumber)
    print (secondNumber)
    
    for number in 1...until{
        
        let num = firstNumber + secondNumber
        print (num)
        
        firstNumber = secondNumber
        secondNumber = num
        
    }
    
    
}
fibonacci(until: 5)
