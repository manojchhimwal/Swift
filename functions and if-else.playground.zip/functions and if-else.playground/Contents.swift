import UIKit

// function to buy some milk

func getMilk(howManyMilkCartons:Int, moneyGiven:Int) -> Int{
    
    print("go to the shop")
    print("buy \(howManyMilkCartons) cartons of milk")
    
    let priceToPay = howManyMilkCartons * 2
    
    print("pay $\(priceToPay)")
    print("come home")
    
    return moneyGiven - priceToPay
}

var amountofChange = getMilk(howManyMilkCartons: 4,moneyGiven: 10)

print("here is your change \(amountofChange)")



// love calculator


func loveCalculator(yourName:String,YourPartnerName:String)-> String{
    
    let lovePercent = arc4random_uniform(101)
    
    if lovePercent > 80 {
        return "you loved each other and your love percentage is \(lovePercent)"
    }else if lovePercent > 60 && lovePercent <= 80{
        return "you can be together and your love percentage is \(lovePercent)"
    }else if lovePercent > 40 && lovePercent <= 60 {
        return "can say anything can be together or not and your percentage is \(lovePercent)"
    }else{
        return "there is no chance for love low percentage of \(lovePercent)"
    }
    
}

print(loveCalculator(yourName: "Manoj", YourPartnerName: "Rahul"))

