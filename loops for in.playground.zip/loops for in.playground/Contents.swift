import UIKit


//let array = [1,5,4,6,8,93,51]
//
//var sum:Int = 0
//for number in 1...10 where number % 2 == 0 {
//   print(number)
//}


// 99 bottles of beer


func beerSong(withHowManyBottles:Int) ->String{
    
    var lyrics:String = ""
    
    for number in (2...withHowManyBottles).reversed(){
   
        var newLine = "\n\( number) bottles of beer on the wall, \(number) bottles of beer.\nTake one down and pass it around, \(number - 1) bottles of beer on the wall.\n"
        
        lyrics += newLine
    }
    
    lyrics += "\n1 bottle of beer on the wall, 1 bottle of beer.\nTake one down and pass it around, no more bottles of beer on the wall.\n"
    lyrics += "\nNo more bottles of beer on the wall, no more bottles of beer.\nGo to the store and buy some more, 99 bottles of beer on the wall."
    
    return lyrics
}


print(beerSong(withHowManyBottles: 99))











