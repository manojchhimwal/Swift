import UIKit

//variables
// use camel case for variable declaration

var a = "hello world"

a = "hello playground"

//var a = "hello"  // it is also invalid redeclaration hence a is already define so var is not needed

print(a)  // it can be redeclare hnece it is not constant like let


// constant variables

let b = "playground"

 //var b = "hello playground"  // redeclaration not allowed

print(b)

//some mathematic operation
let c = 22;
let d = 25;

print(c + d);
print(c - d);
print(c * d);
print(c / d);
print(c % d);


//Data Types

var str:String = "Manoj Chhimwal";
var num:Int = 23; // positive and negative both
var fl:Float = 2.34 //for less decimal places
var db:Double = 2.5674 // for more decimal places
var bool:Bool = true

// To change data types

print (Int(fl));
print (Float(num));
print (String(db));
print(bool);
print(Int(round(db)));


// if-else statements

let num1 = 10 ;

if(num1 > 10){
    print("number is greater than 10")
}else if (num1 < 10 ){
    print("number is less than 10")
}else if (num1 == 10){
    print("number is equal to 10")
}
else{
    print("nothing")
}

let num2 = 15;
let num3 = 20;

if num1 < 10 || (num2 > 10 && num3 < 15)
{
    print("branch 1");
    
}else if (num1 >= 10) && num2 <= 20{
    print("branch 2");
}else if num3 != 20{
    print("branch 3");
}else if !(num3 >= 25){
 print("branch 4")
}else{
    print("no branch")
}


//switch Statements

var someCharacter:Character = "d";

switch someCharacter{
case "a","A":                 // multiple statement can be used
    print("is an A")
case "b","B","c","C":                 // for example
    print("is an B or C")
default :
    print("no Above character" , someCharacter , "is define");
}


//loops

// for index in 1...5 (low value to high value)
// while loop
// repeat while loop

//for loop

for index in 1...5{
//for _ in 1...5{
    //print(_);   // we can't print _
     print(index);
  //  print("hello");
}

// print(index)  //scope inside the loop only

var sum = 0;

for index in 1...5{
    sum += index;
    print (sum);
}

print (sum);


//while loop


var counter = 5;

while (counter > 0){
    print(counter)
    counter -= 1
}


// repeat while loop
var count = 5
// it will execute once if the statement is false also;
repeat {
    print("hello",count)
    count -= 1
}while count < 0



//Function


func subTwoNumber(){
    let first = 10
    let second = 20
    let result = second  - first;
    print(result)
}

subTwoNumber()

//for return value

func addTwoNumber() -> Int{
        let one = 10
        let two  = 20
        let res = one + two ;
        return res;
}

var addition = addTwoNumber()
print(addition);


//function parameter

func functionName(arg param:DataType,arg1 param1:DataType)-> DataType{
    //some code;
    return;
}


func multiTwoNumber(para:Int, para1:Int)->Int{
    // can also omit arg and para treated as arg name;
    let multione = para
    let multitwo = para1
    return multione * multitwo;
}

var multiResult = multiTwoNumber(para: 10, para1: 10)
print (multiResult);


//divide function

func divTwoNumber(_ para:Int,_ para1:Int)->Int{
    return para / para1
}

let divResult = divTwoNumber(10000, 10)
print(divResult);
































































































